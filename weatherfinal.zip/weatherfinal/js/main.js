(function () {
	window.addEventListener("tizenhwkey", function (ev) {

		var activePopup = null,
			page = null,
			pageid = "";

		if (ev.keyName === "back") {
			activePopup = document.querySelector(".ui-popup-active");
			page = document.getElementsByClassName("ui-page-active")[0];
			pageid = page ? page.id : "";

			if (pageid === "main" && !activePopup) {
				try {
					tizen.application.getCurrentApplication().exit();
				} catch (ignore) {
				}
			} else {
				window.history.back();
			}
		}
	});
}());

//우산지수 해설
function today_metric(precip_today_metric, precip, precip_s){
    if(precip_today_metric>3 && precip>=50){
        precip_s +='<h6>&nbsp;Take Umbrella</h6>';
    }else{
        precip_s +='<h6>&nbsp;Not need Umbrella</h6>';
    }
    return precip_s;
}
//세차지수 해설
function today_clean_car(precip, clean_car_s){
    if(precip>=50){
        clean_car_s +="<h6>&nbsp;Next time, wash car</h6>";
    }else{
        clean_car_s +="<h6>&nbsp;A good day to wash car</h6>";
    }
    return clean_car_s;
}
//수면지수 해설
function today_sleep(relative_humidity, sleep_s){
    if(relative_humidity >=50){
        sleep_s +='<h6>&nbsp;Need air conditionig</h6>';
    }else{
        sleep_s +='<h6>&nbsp;It`s good to sleep</h6>';
    }
    return sleep_s;
}
//빨래지수 해설
function today_clean_clothes(clean_clothes, clean_clothes_s){
    if(clean_clothes >=50){
        clean_clothes_s +='<h6>&nbsp;Do not wash</h6>';
    }else{
        clean_clothes_s +='<h6>&nbsp;Good day to laundry</h6>';
    }
    return clean_clothes_s;
}


var tip_count = 0;
var $my_region;	//지역설정명
var count=0;	//지역 중복선택 카운트
var $area; 		// 미세먼지 측정소
var xmlHttp;
var rand = Math.floor(11*Math.random()); // 디비에서 무작위 정보를 가져오기 위한 난수

function createXMLHttpRequest() {
	if(window.ActiveXObject) {
		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		//xmlHttp = new XMLHttpRequest();
		var url = "http://localhost:3100";
		xmlHttp.open("GET", url, true);
		xmlHttp.send("test");
		xmlHttp.onreadystatechange = loader;
		
		console.log("chrome");
	} else if(window.XMLHttpRequest) {
		xmlHttp = new XMLHttpRequest();
		var url = "http://localhost:3100";
		xmlHttp.open("GET", url, true);
		xmlHttp.send("test");
		xmlHttp.onreadystatechange = loader;
		
		console.log("chrome");
	}
}

function loader() {
	var temp;
	console.log(xmlHttp.readyState);
	console.log(xmlHttp.status);
	console.log(xmlHttp.responseText);	//디비에서 가져온 텍스트

	

	if(xmlHttp.readyState == 4) {
		if(xmlHttp.status == 200) {
			temp = xmlHttp.responseText;
			alert(temp);
			console.log(temp);
			console.log("test");

		}if(xmlHttp.status == 304) {
			temp = xmlHttp.responseText;
			alert(temp);
			console.log(temp);
			console.log("test");

		}
	}
}

//지역설정 버튼 클릭시 실행
function regions() {
	console.log("test");
	createXMLHttpRequest();
	var region = document.getElementById("region");
	if(region.options[region.selectedIndex].value === "empty"){
		alert("Set Region");
	}else {
		$my_region = region.options[region.selectedIndex].value;
		//alert($rr +"(으)로 설정되었습니다.");
		regionset();
		count = 1;
		switch ($my_region){	//선택된 지역에 맞는 미세먼지 측정소 설정
	        case "seoul":

	        	$area = "강남구";
	         	break;
	      	case "incheon":
	    	 	$area = "부평";
	    	 	break;
	      	case "suwon":
		 		$area = "동수원";
			 	break;
	      	case "seongnam":
			 	$area = "모란역";
			 	break;
	      	case "gangneung":
		     	$area = "옥천동";
		     	break;
		  	case "chuncheon":
		     	$area = "중앙로";
		     	break;
		  	case "daejeon":
		     	$area = "구성동";
			 	break;
		  	case "cheonan":
		     	$area = "백석동";
		     	break;
		  	case "daegu":
		     	$area = "수창동";
		     	break;	     
		  	case "jeonju":
			 	$area = "중앙동(전주)";
			 	break;
	      	case "gwangju":
	    	 	$area = "주월동";
	    	 	break;
	      	default :
	         	$area = "";
	      	 	break;
		}	
		dustset($area);
	}
}

//지역 설정 함수
function regionset(){
		// 지역이 선택되있는경우
		$(document).ready(function($){
			 tip_count++;
			//alert("weatherss"+$rr);
			  $.ajax({
			  	// 결과를 한글로 받을 수 있다.
				url : "http://api.wunderground.com/api/19519d0a0d1744e1/geolookup/conditions/lang:KR/q/Korea/"+$my_region+".json",
			    dataType : "jsonp",
			    success : function(parsed_json) {
			  	    // 관측 장소 정보
				    var location = parsed_json.location;
				  	var location_s= "<h6>Location&nbspCity:&nbsp"+location.city+"</h6>";
				  	$("#location_info").empty();
					$("#location_info").append(location_s);
					var observ = parsed_json.current_observation;	
					 
					// 현재날씨 정보
					var temperature = parsed_json.current_location;
					var temperature_s = "<h4>Real Time Weather</h4>";
					temperature_s += "<h6><img src='"+observ.icon_url+"'/></h6>";
					temperature_s += "<h6>"+observ.icon+"</h6>";
					temperature_s += "<h6>Real Time Temp (℃) : "+observ.temp_c+"℃ "+"</h6>";
					var now_temp = parseFloat(observ.temp_c);
					temperature_s +="<h6>Humidity :  "+observ.relative_humidity+"</h6>";
					var now_humidity = parseFloat(observ.relative_humidity);
					$("#temperature_info").empty();
					$("#temperature_info").append(temperature_s);
					 
					//바람상황 정보
					var wind = parsed_json.current_location;
					var wind_s = "<h4>Wind</h4>";
					switch(observ.wind_dir){
					 	case "동":
					 		observ.wind_dir= "E";
					 		break;
					 	case "서":
					 		observ.wind_dir= "W";
					 		break;
					 	case "남":
					 		observ.wind_dir= "S";
						 	break;
					 	case "북":
					 		observ.wind_dir= "N";
						 	break;
						 	
					 	case "남동":
					 		observ.wind_dir= "SE";
						 	break;
					 	case "남서":
					 		observ.wind_dir= "SW";
						 	break;
					 	case "북동":
					 		observ.wind_dir= "NE";
						 	break;
					 	case "북서":
					 		observ.wind_dir= "NW";
						 	break;	 
		
					 	case "동북동":
					 		observ.wind_dir= "ENE";
						 	break;
					 	case "동동남":
					 		observ.wind_dir= "EES";
						 	break;
					 	case "동동북":
					 		observ.wind_dir= "EEN";
						 	break;
					 	case "동북북":
					 		observ.wind_dir= "ENN";
						 	break;
					 	case "동남동":
					 		observ.wind_dir= "ESE";
						 	break;
					 	case "동남남":
					 		observ.wind_dir= "ESS";
						 	break;
						 	
					 	case "서서남":
					 		observ.wind_dir= "WWS";
						 	break;
					 	case "서서북":
					 		observ.wind_dir= "WWN";
						 	break;
					 	case "서남서":
					 		observ.wind_dir= "WSW";
						 	break;
					 	case "서남남":
					 		observ.wind_dir= "WSS";
						 	break;
					 	case "서북서":
					 		observ.wind_dir= "WNW";
						 	break;
					 	case "서북북":
					 		observ.wind_dir= "WNN";
						 	break;
						 	
					 	case "남동남":
					 		observ.wind_dir= "SES";
						 	break;
					 	case "남동동":
					 		observ.wind_dir= "SEE";
						 	break;
					 	case "남서남":
					 		observ.wind_dir= "SWS";
						 	break;
					 	case "남서서":
					 		observ.wind_dir= "SWW";
						 	break;
					 	case "남남동":
					 		observ.wind_dir= "SSE";
						 	break;
					 	case "남남서":
					 		observ.wind_dir= "SSW";
						 	break;
						 	
					 	case "북동북":
					 		observ.wind_dir= "NEN";
						 	break;
					 	case "북동동":
					 		observ.wind_dir= "NEE";
						 	break;
					 	case "북서북":
					 		observ.wind_dir= "NWN";
						 	break;
					 	case "북서서":
					 		observ.wind_dir= "NWW";
						 	break;
					 	case "북북동":
					 		observ.wind_dir= "NNE";
						 	break;
					 	case "북북서":
					 		observ.wind_dir= "NNW";
						 	break;		
					}
					wind_s += "<h6>Wind Direction :  "+observ.wind_dir+"</h6>";
					wind_s += "<h6>Wind Speed (mph):  "+observ.wind_mph+"</h6>";
					$("#wind_info").empty();
					$("#wind_info").append(wind_s);
					 
					// 자외선정보
					var uvray = parsed_json.current_location;
					var uvray_s = "<h4>UV Info</h4>";
					uvray_s += "<h6>UV Value :  "+observ.UV+"</h6>";
					var now_uv = parseFloat(observ.UV);
					$("#uvray_info").empty();
					$("#uvray_info").append(uvray_s);

					$("#life_tips").empty();
					$("#life_tips").append("<h4>Useful Info.<h4>");	
					 
					
					var json_obj = $.parseJSON(xmlHttp.responseText);
					 
					var tip_s = "<h6>오늘의 팁 : "+ json_obj[rand].tips +"</h6>";
					// 난수를 정수형으로 뽑은 후, db에서 받아온 json형식 데이터로 만든 object에서 출력
					
					
					
					//서버 db 없이 테스트 용
//					if (tip_count == 0){
//						var tip_s = "<h6>Put a peeled pot into an apple shell and boil it and rub it.</h6>";	 
//					}else if(tip_count == 1){
//						var tip_s = "<h6>Using Microwave, Empty the center and warm it up better.</h6>";
//					}else if(tip_count == 2){
//						var tip_s = "<h6>The inked clothes are wiped off by brushing with water spray</h6>";
//					}else if(tip_count == 3){
//						var tip_s = "<h6>If you put a flower in a bottle with a soda water, it will last long.</h6>";
//					}else if(tip_count == 4){
//						var tip_s = "<h6>Hiccups can be stopped by pulling your tongue with your fingers.</h6>";
//					}else if(tip_count == 5){
//						var tip_s = "<h6>Wrap the beverage in a kitchen towel and put it in the refrigerator and it will be cold.</h6>";
//					}else if(tip_count == 6){
//						var tip_s = "<h6>The grease on your hands is removed well with sugar.</h6>";
//					}else if(tip_count == 7){
//						var tip_s = "<h6>If you put a copper coin in your shoes, the smell is removed</h6>";
//					}else if(tip_count == 8){
//						var tip_s = "<h6>Washing the rag with an egg shell makes it clean.</h6>";
//					}else{
//						var tip_s = "<h6>It is well lubricated if you put it in a nail..</h6>";
//					}
					 
					$("#life_tips").append(tip_s);
				 
				
					//생활지수
				 	var banner_location ="<h4>" + location.city +"</h4>";
		         	$(".main-banner .location").prepend(banner_location);

		        	//초기화
					$(".main-banner #imgban1 .box dd span").empty();
					$(".main-banner #imgban2 .box dd span").empty();
					$(".main-banner #imgban1 .box dd h6").empty();
					$(".main-banner #imgban2 .box dd h6").empty();
					$(".main-banner #imgban1 .box dd .st").empty();
					$(".main-banner #imgban2 .box dd .st").empty();
					
					//우산지수
		         	var precip =observ.precip_today_in;
		         	precip =precip*100;
		         	precip =precip -precip%10;
		         	var precip_s = "<strong class='st'>&nbsp;Umbrella Index</strong>";
		         	precip_s +="<span style ='color:#FF6A00 '>"+precip+"</span>";
		         	precip_s =today_metric(observ.precip_today_metric, precip, precip_s);
		         	$(".main-banner #imgban2 li:first-child .st").append(precip_s);
		         	//세차지수
		         	var clean_car_s = "<strong class='st'>&nbsp;Wash Car Index</strong>";
		         	clean_car_s +="<span style ='color:#FF6A00 '>"+(100-precip)+"</span>";
		         	clean_car_s =today_clean_car(precip, clean_car_s);
		         	$(".main-banner #imgban1 li:last-child .st").append(clean_car_s);
		         	//수면지수
		         	var sleep =observ.relative_humidity.substring(0,2);
		         	sleep =sleep -sleep%10;
		         	var sleep_s = "<strong class='st'>&nbsp;Sleep Index</strong>";
		         	sleep_s +="<span style ='color:#FF6A00 '>"+(100-sleep)+"</span>";
		         	sleep_s =today_sleep(sleep, sleep_s);
		         	$(".main-banner #imgban2 li:last-child .st").append(sleep_s);
		         	//빨래지수
		         	var clean_clothes =sleep;
		         	var clean_clothes_s = "<strong class='st'>&nbsp;Laundry Index</strong>";
		         	clean_clothes_s +="<span style ='color:#FF6A00 '>"+(100-clean_clothes)+"</span>";
		         	clean_clothes_s =today_clean_clothes(clean_clothes, clean_clothes_s);
		         	$(".main-banner #imgban1 li:first-child .st").append(clean_clothes_s);
			  	}
			});
		});
	//	
}

// 미세먼지 설정 함수
function dustset(area){
	my_area = area;
	if(count==1){	// 지역이 선택되있는경우
		$(document).ready(function($){
			  $.ajax({
				    type:"get"
				    ,dataType:"xml"
				    ,url : "http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty?stationName="+my_area+"&dataTerm=month&pageNo=1&numOfRows=1&ServiceKey=VTTa0BejDtySgTCMSGuNcjvB6UQlZHtoDS2O1qxIrtaxsmtMFmn2dk6lfq1rJuNH82zfyKuHlu/0nLNrjTDPyQ==&ver=1.3"
				    ,success:function(xml){
				     if($(xml).find("item").length > 0){
				      $(xml).find("item").each(function() {		   		       			    
				    	  var dust = "<h6>Dust Concentration (㎍/㎥) : </h6>"+$(this).find("pm10Value").text();
				    	  dust += "<h6>Dust Grade : </h6>"+$(this).find("pm10Grade").text();
				    	  $('#dust_info').empty();
					      $('#dust_info').append(dust);
					        	             		       
				      });
				     }	     
				    },
		  error : function(request,status,error) {
			  alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
			  console.log(error);
		  },	
		  });
		});
	}
	else{
		$(document).ready(function($){
			  $.ajax({
				    type:"get"
				    ,dataType:"xml"
				    ,url : "http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty?stationName=강남구&dataTerm=month&pageNo=1&numOfRows=1&ServiceKey=VTTa0BejDtySgTCMSGuNcjvB6UQlZHtoDS2O1qxIrtaxsmtMFmn2dk6lfq1rJuNH82zfyKuHlu/0nLNrjTDPyQ==&ver=1.3"
				    ,success:function(xml){
				     if($(xml).find("item").length > 0){
				      $(xml).find("item").each(function() {//each >> for문 같은기ㅇㅇ		   		       			    
				    	  var dust = "<h6>Dust Concentration (㎍/㎥) : </h6>"+$(this).find("pm10Value").text();
				    	  dust += "<h6>Dust Grade : </h6>"+$(this).find("pm10Grade").text();
				    	  $('#dust_info').empty();
					      $('#dust_info').append(dust);	             		       
				      });
				     }	     
				    },
		  error : function(request,status,error) {
			  alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
			  console.log(error);
		  },	
		  });
		});
	}
}
